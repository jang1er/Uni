package eidi2.sose2022.admission_exam.group03.animal;

public interface CanFly {
	public boolean isAirborne();
	public void land();
	public void takeOff();
}
